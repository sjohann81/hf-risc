#ifndef _ASM_RISCV_BITSPERLONG_H
#define _ASM_RISCV_BITSPERLONG_H

#define __BITS_PER_LONG _RISCV_SZLONG

#include <asm-generic/bitsperlong.h>

#endif /* _ASM_RISCV_BITSPERLONG_H */
