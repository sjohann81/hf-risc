/* Pull in __syscall_error.  */
#include <sysdep.c>
