#ifndef _ASM_RISCV_AUXVEC_H
#define _ASM_RISCV_AUXVEC_H

/* vDSO location */
#define AT_SYSINFO_EHDR 33

#endif /* _ASM_RISCV_AUXVEC_H */
