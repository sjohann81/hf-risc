#include <sysdeps/unix/sysv/linux/i386/putmsg.c>
