#include <sysdeps/unix/sysv/linux/mips/mips32/sync_file_range.c>
