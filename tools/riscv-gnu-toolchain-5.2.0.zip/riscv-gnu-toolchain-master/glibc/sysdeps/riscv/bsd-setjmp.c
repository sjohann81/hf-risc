/* setjmp is implemented in setjmp.S */
